<?php
/**
 * Pages.
 *
 * @package Tassili_Immobilier
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="site-main">
	<?php
	while ( have_posts() ) :
		the_post();
		if ( tassili_is_elementor_post( get_the_ID() ) ) :
			the_content();
			continue;
		endif;
		?>
		<div class="page-head">
			<div class="container">
				<h1><?php the_title(); ?></h1>
			</div>
		</div>
		<div class="container page-wrap">
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-thumb" style="max-width:72ch;margin-bottom:var(--s-5)"><?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:var(--r-lg)' ) ); ?></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages(
						array(
							'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Page', 'tassili-immobilier' ) . '">',
							'after'  => '</nav>',
						)
					);
					?>
				</div>
			</article>
			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
			?>
		</div>
	<?php endwhile; ?>
</main>
<?php
get_footer();
